exports.handler = async () => {
  console.log("hello from lambda B");
  return "has been invoke!"
}
