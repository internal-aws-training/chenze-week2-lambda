exports.handler = async (event, context, callback) => {
  console.log("hello from lambda B")
}
